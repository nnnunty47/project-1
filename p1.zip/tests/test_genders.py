import sys
sys.path.append('..')

from redactor import gender_encrpty

text = "He is my father. I think we are family."
print(text)
print(gender_encrypt(text, '\u2588'))