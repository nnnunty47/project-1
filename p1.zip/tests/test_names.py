import sys
sys.path.append('..')

from redactor import name_encrpty

text = "Mike is my father. I think we are family."
print(text)
print(name_encrypt(text, '\u2588'))