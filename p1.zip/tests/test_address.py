import sys
sys.path.append('..')

from redactor import address_encrypt

text = "I'm from Canada. My phone number is 713-582-8379, you can call me any time."
print(text)
print(address_encrypt(text, '\u2588'))