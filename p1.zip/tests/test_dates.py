import sys
sys.path.append('..')

from redactor import date_encrpty

text = "Date: Thu, 29 Nov 2001 08:09:20 -0800 (PST)."
print(text)
print(date_encrypt(text, '\u2588'))