import sys
sys.path.append('..')

from redactor import phone_encrypt

text = "My phone number is 713-582-8379, you can call me any time."
print(text)
print(phone_encrypt(text, '\u2588'))