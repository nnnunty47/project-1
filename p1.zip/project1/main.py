import sys
sys.path.append('..')
from redactor import *


def parse_config(argv):
    config = {'names': False, 'genders': False, 'dates': False, 'phones': False, 'address': False, 'input': [],
              'output': str(), 'stats': sys.stdout}

    n = len(argv)
    i = 0
    while i < n:
        if argv[i] == '--names':
            config['names']  = True
            i += 1

        elif argv[i] == '--genders':
            config['genders']  = True
            i += 1

        elif argv[i] == '--dates':
            config['dates']  = True
            i += 1

        elif argv[i] == '--phones':
            config['phones']  = True
            i += 1

        elif argv[i] == '--address':
            config['address']  = True
            i += 1

        elif argv[i] == '--input':
            config['input'].append(argv[i + 1])
            i += 2
        elif argv[i] == '--output':
            config['output'] = argv[i + 1]
            i += 2
        elif argv[i] == '--stats':
            if argv[i + 1] == 'stderr':
                config['stats'] = sys.stderr
            elif argv[i + 1] == 'stdout':
                config['stats'] = sys.stdout
            else:
                config['stats'] = open(argv[i + 1], 'w')
            #config['stats'] = argv[i + 1]
            i += 2
        else:
            i += 1

    return config

if __name__ == '__main__':
    
    config = parse_config(sys.argv[1::])
    print(f'config parameters: {config}', file = config['stats'])
    block_character = '\u2588'
    for input_file in config['input']:
        for filename in glob.glob(input_file):
            print(f'encode file: {filename}', file = config['stats'])
            encode(filename, config)
    if config['stats'] != sys.stderr and config['stats'] != sys.stdout:
        config['stats'].close()
